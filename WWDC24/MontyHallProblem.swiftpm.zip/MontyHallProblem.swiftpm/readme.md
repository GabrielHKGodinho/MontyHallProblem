#  Images used:
<a href="https://www.freepik.com/free-vector/set-inedible-fruit-with-mould_28814537.htm#query=rotten%20fruit&position=9&from_view=search&track=ais&uuid=75233b41-45a7-4267-9bb3-7677048ddf7a">Image by brgfx</a> on Freepik

<a href="https://www.freepik.com/premium-vector/vector-dirty-torn-socks-cartoon-style_28897477.htm">Image by natasha-tpr</a> on Freepik

Image by <a href="https://pixabay.com/users/openclipart-vectors-30363/?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=149626">OpenClipart-Vectors</a> from <a href="https://pixabay.com//?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=149626">Pixabay</a>

Songs:

Strollin' - TrackTribe - from YoutubeStudio
Jane Street - TrackTribe - from YoutubeStudio

MP3s:

aww - https://freesound.org/people/phmiller42/sounds/124996/
Audience_Applause - https://freesound.org/people/unchaz/sounds/150953/
Applause, huge, thunderous - https://freesound.org/people/peridactyloptrix/sounds/196094/
TV-Static-Sound.ogg - https://freesound.org/people/JohnnyRaySounds/sounds/385872/
Door Squeak, Normal, D.wav - https://freesound.org/people/InspectorJ/sounds/346212/
